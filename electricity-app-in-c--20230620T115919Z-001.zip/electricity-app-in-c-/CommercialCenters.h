#include <iostream>
using namespace std;

float getCommercialCenters (float money){
	float tunits= money /179;
	return tunits;
}

