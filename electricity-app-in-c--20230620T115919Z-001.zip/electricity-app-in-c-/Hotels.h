#include <iostream>
using namespace std;

float Hotels(float money){
	float tunits= money /157;
	return tunits;
}
