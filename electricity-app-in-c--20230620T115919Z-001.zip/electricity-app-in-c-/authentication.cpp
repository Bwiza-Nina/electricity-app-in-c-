#include <iostream>
#include <fstream>
#include <string.h>
#include "Functions.h"
using namespace std;

void login();
void registration();
void forgot();

int main(){
	system("color F1");
	int c;
	cout << "\t\t\t__________________________________________________\n\n\n";
	cout << "\t\t\t             Welcome To The Login Page            \n\n\n";
	cout << "\t\t\t_______________    MENU           __________________\n\n";
	cout << "                                                        \n\n\n";
	cout << "\t| Press 1 to LOGIN                                 |"<<endl;
	cout << "\t| Press 2 to REGISTER                              |"<<endl;
	cout << "\t| Press 3 if you forgot ur password                |"<<endl;
	cout << "\t| Press 4 to EXIT                                  |"<<endl;
	cout << "\n\t\t\t Please enter your choice: ";
	cin>>c;
	cout<<endl;
	
	switch(c){
		case 1:
			login();
			break;
		case 2:
			registration();
			break;
		case 3:
			forgot();
			break;
		case 4:
			cout<<"Thank you for using our application"<<endl;
			break;
		default:
			system("cls"); //clear the screen
			cout<<"You have selected an invalid number, select from the given options \n"<<endl;
			main();
	}
}

void login(){
	int count;
	string userId, password, id, pass;
	system("cls");
	cout << "\t\t\t Please enter the username and password: "<<endl;
	cout << "\t\t\t USERNAME: ";
	cin>>userId;
	cout << "\t\t\t PASSWORD: ";
	cin>>password;
	
	ifstream input("records.txt");
	while(input>>id>>pass){
		if(id==userId && pass==password){
			count=1;
			system("cls");
		}
	}
	input.close();
	int option;
	if(count=1){
		cout<<userId<<" Logged in successfully";
		cout << "\t\t\t__________________________________________________\n\n\n";
	cout << "\t\t\t       Welcome To Buying Electricity Application       \n\n\n";
	std::cout << "\t\t\t|         OPTIONS MENU                     |\n";
std::cout << "\t\t\t===========================================\n";
std::cout << "\t\t\t| 1 = User Cashpower Register              |\n";
std::cout << "\t\t\t| 2 = Buying Electricity                   |\n";
std::cout << "\t\t\t| 3 = Exit program                         |\n";
std::cout << "\t\t\t===========================================\n";
std::cout << "\t\t\t Enter your option:";
std::cin >> option;

do {
    switch (option) {
        case 1:
            registerCashpower(); // Assuming registerCashpower() is defined in functions.h
            option = 1;
            break;
        case 2:
            BuyElectricity(); // Assuming BuyElectricity() is defined in functions.h
            option = 2;
            break;
        case 3:
            exitProgram(); // Assuming exitProgram() is defined in functions.h
            option = 3;
            break;
        default:
            std::cout << "\n\n\t\t\tSorry! Option not found!";
            std::cout << "\n\n\t\t\tWant to continue? Enter another option: ";
            std::cin >> option;
    }
} while (option < 4);

std::cout << "\n";
return 0;

	}
	else{
		cout<<"Login error, please check your username or password";
		main();
	}
}

void registration(){
	string ruserId, rpassword, rid, rpass;
	system("cls");
	cout<<"\t\t\t Enter the username: ";
	cin>>ruserId;
	cout<<"\t\t\t Enter the password: ";
	cin>>rpassword;
	
	ofstream f1("records.txt", ios::app);
	f1<<ruserId<<' '<<rpassword<<endl;
	system("cls");
	cout<<"\n\t\t\t Registration is successfull! \n";
	main();
}
void forgot(){
	int option;
	system("cls");
	cout<<"\t\t\t You forgot the password? No worries \n";
	cout<<"Press 1 to search your id by username: "<<endl;
	cout<<"Press 2 to go back to the main menu: "<<endl;
	cout<<"\t\t\t Enter your choice: ";
	cin>>option;
	switch(option){
		case 1: {
			int count=0;
			string suserId, sid, spass;
			cout<<"\n\t\t\t Enter the username which you remembered: ";
			cin>>suserId;
			
			ifstream f2("records.txt");
			while(f2){
				if(sid==suserId){
					count=1;
				}
			}
			f2.close();
			if(count==1){
				cout<<"\n\n Your account is found! \n";
				cout<<"\n\n Your password is: "<<spass;
				main();
			}
			else{
				cout<<"\n\t Sorry! Your account is not found! \n";
				main();
			}
			break;
		}
		case 2:
			{
				main();
			}
		default:
			cout<<"\t\t\t Wrong choice! Please try again"<<endl;
			forgot();
	}
}
