#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <string>

#include "Broadcasters.h"
#include "CommercialCenters.h"
#include "Hotels.h"

int cashPowerNumber;
char* customerFirstName;
char* customerLastName;

struct Customer {
    int id;
    char fname[40];
    char lname[40];
    int categoryId;
    int cashpowerNumber;
    float tunits;
};

struct boughtElectricity {
	float tunits;
	float boughtUnits;
};

float findTUnits(int cashPowerNo) {
    Customer customer1;
    std::ifstream file("storage/customers.csv", std::ios::binary);

    if (!file.is_open()) {
        std::cout << "Error opening file." << std::endl;
        return 0;
    }

    while (file.read(reinterpret_cast<char*>(&customer1), sizeof(customer1))) {
        if (customer1.cashpowerNumber == cashPowerNo) {
            file.close();
            return customer1.tunits;
        }
    }

    file.close();
    return 0;
}

std::string searchUser(int cashPowerNo) {
    Customer customer1;
    std::ifstream file("storage/customers.csv");

    if (!file.is_open()) {
        std::cout << "Error opening file." << std::endl;
        return "";
    }

//    while (file >> customer1.id >> customer1.fname >> customer1.lname >> customer1.categoryId >> customer1.cashpowerNumber >> customer1.tunits) {
//        if (customer1.cashpowerNumber == cashPowerNo) {
//            file.close();
//            std::cout << "\t\t\tCustomer name: " << customer1.fname << " " << customer1.lname << std::endl;
//            return customer1.fname;
//        }
//    }
    if (customer1.cashpowerNumber == cashPowerNo) {
    	while (file >> customer1.id >> customer1.fname >> customer1.lname >> customer1.categoryId >> customer1.cashpowerNumber >> customer1.tunits){
            file.close();
            std::cout << "\t\t\tCustomer name: " << customer1.fname << " " << customer1.lname << std::endl;
            return customer1.fname;
        }
    }

    file.close();
    return "";
}

int searchCashPowerCategory(int cashPowerNo) {
    Customer customer1;
    std::ifstream file("storage/customers.csv");

    if (!file.is_open()) {
        std::cout << "Error opening file." << std::endl;
        return -1;
    }

    if (customer1.cashpowerNumber == cashPowerNo) {
    	while (file >> customer1.id >> customer1.fname >> customer1.lname >> customer1.categoryId >> customer1.cashpowerNumber >> customer1.tunits){
            file.close();
            return customer1.categoryId;
        }
    }

    file.close();
    std::cout << "Not found!" << std::endl;
    return -1;
}

int printElecticityDetails(float units, int cashpower, float money) {
    std::cout << "\t\t\tProcessing....." << std::endl;
    std::cout << std::endl;
    std::cout << "\t\t\tE-STEP Electricity: \t";
    int n;
    srand(time(NULL));
    for (n = 0; n < 4; n++)
        std::cout << std::setw(5) << std::setfill('0') << rand() % 10000;
    std::cout << std::endl;
    std::cout << "\t\t\telectricity paid: " << units << "KWH" << std::endl;
    std::cout << "\t\t\tcashpower number: " << cashpower << std::endl;
    std::cout << "\t\t\ttotal amount cost: " << money << "Frw" << std::endl;
    std::cout << "\t\t\ttransaction done on " << __DATE__ << std::endl;
    std::cout << "\t\t\t-----------------------------------------" << std::endl;
    std::cout << std::endl << std::endl;
    exit(-1);
}

void exitProgram() {
    system("color 07");
    std::cout << std::endl << std::endl;
    std::cout << "\t\t\tGood Customer, thank you for using this program." << std::endl << std::endl;
}

int registerCashpower() {
    srand(time(0));
    int randId;
    randId = rand();
    int userID = randId;
    Customer newCustomer;
    newCustomer.id = userID;
    FILE* ptr;
    ptr = fopen("storage/customers.csv", "a");
    system("color 07");
    std::cout << "\n\t\t\t REGISTER NEW CASHPOWER" << std::endl;
    std::cout << "\n\t\t\t--------------------------\n\n";
    std::cout << "\t\t\tEnter your Firstname:";
    std::cin >> newCustomer.fname;
    std::cout << "\t\t\tEnter your Lastname:";
    std::cin >> newCustomer.lname;

    int option;
    std::cout << "\t\t\t|         CATEGORIES AVAILABLE                                 |\n";
    std::cout << "\t\t\t===============================================================\n";
    std::cout << "\t\t\t| 1 = residential                                              |\n";
    std::cout << "\t\t\t| 2 = non residential                                          |\n";
    std::cout << "\t\t\t| 3 = telecom towers                                           |\n";
    std::cout << "\t\t\t| 4 = water treatment plants and pumping stations              |\n";
    std::cout << "\t\t\t| 5 = hotels                                                   |\n";
    std::cout << "\t\t\t| 6 = health facilities                                        |\n";
    std::cout << "\t\t\t| 7 = Broadcasters                                             |\n";
    std::cout << "\t\t\t| 8 = commercial data centers                                  |\n";
    std::cout << "\t\t\t===============================================================\n";
    std::cout << "\t\t\tChoose your category:";
    std::cin >> option;
    do {
        switch (option) {
        case 1:
            newCustomer.categoryId = 1;
            option = 9;
            break;
        case 2:
            newCustomer.categoryId = 2;
            option = 9;
            break;
        case 3:
            newCustomer.categoryId = 3;
            option = 9;
            break;
        case 4:
            newCustomer.categoryId = 4;
            option = 9;
            break;
        case 5:
            newCustomer.categoryId = 5;
            option = 9;
            break;
        case 6:
            newCustomer.categoryId = 6;
            option = 9;
            break;
        case 7:
            newCustomer.categoryId = 7;
            option = 9;
            break;
        case 8:
            newCustomer.categoryId = 8;
            option = 9;
            break;
        default:
            std::cout << "\n\n\t\t\tSorry! Option not found!";
            std::cout << "\n\n\t\t\tWant to continue? Enter another option:";
            std::cin >> option;
        }
    } while (option < 9);
    std::cout << std::endl;
    // Randomly generate cash power number
    srand(time(0));
    newCustomer.cashpowerNumber = (rand() % (99999999999 - 10000000000 + 1)) + 10000000000;
    newCustomer.tunits = 0;
    std::cout << "\n\t\t\tYour cashpower number is: " << newCustomer.cashpowerNumber;
    if (fwrite(&newCustomer, sizeof(struct Customer), 1, ptr)) {
        std::cout << "\n\n\t\t\tWELCOME! You are now registered!";
        exit(-1);
    }
    fclose(ptr);
}


void BuyElectricity() {
    int cashPowerNo;
    std::cout << "\t\t\tEnter your cashpower number: ";
    std::cin >> cashPowerNo;
    int customerCategoryId = searchCashPowerCategory(cashPowerNo);
    if (customerCategoryId == 0) {
        std::cout << "\n\n\t\t\tYou're not registered! First register to continue";
        registerCashpower();
    }
    float money;
    std::cout << "\n\n\t\t\tEnter the amount of money you want to buy units for: ";
    std::cin >> money;
    searchUser();

    struct boughtElectricity buyingInfo;
    switch (customerCategoryId) {
        case 1: {
            float boughtUnits = Hotels(money);
            UpdateTUnits(cashPowerNo, boughtUnits);
            printElecticityDetails(boughtUnits, cashPowerNo, money);
            break;
        }
        case 2: {
            float boughtUnits = getBroadcaster(money);
            UpdateTUnits(cashPowerNo, boughtUnits);
            printElecticityDetails(boughtUnits, cashPowerNo, money);
            break;
        }
        default: {
            float boughtUnits = getCommercialCenters(money);
            UpdateTUnits(cashPowerNo, boughtUnits);
            printElecticityDetails(boughtUnits, cashPowerNo, money);
        }
    }
}

