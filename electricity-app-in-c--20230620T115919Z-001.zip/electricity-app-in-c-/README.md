# electricity-app-in-c-
Preparing for the c++ national exam practice exam by implementing an electricity app
