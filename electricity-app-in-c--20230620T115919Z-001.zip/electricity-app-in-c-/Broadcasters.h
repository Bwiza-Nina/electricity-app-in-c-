#include <iostream>
#include <string>

float getBroadcaster(float money){
	float tUnits = money / 192;
	return tUnits;
}
